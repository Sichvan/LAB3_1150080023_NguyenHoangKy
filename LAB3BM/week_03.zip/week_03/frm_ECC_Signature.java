package week_03;

import java.awt.*;
import javax.swing.*;

public class frm_ECC_Signature extends javax.swing.JFrame {

    private final ECCSignature ecdsa = new ECCSignature();

    private JTextArea txt_public;
    private JTextArea txt_private;
    private JButton btn_generate;
    private JButton btn_savekeys;
    private JButton btn_loadkeys;
    private JTextArea txt_message;
    private JTextArea txt_signature;
    private JButton btn_sign;
    private JButton btn_verify;
    private JLabel lbl_result;
    private JLabel lbl_status;

    public frm_ECC_Signature() {
        initComponents();
        setLocationRelativeTo(null);
    }

    /** Hiện khóa công khai / khóa riêng (Base64) lên form. */
    private void showKeys() {
        txt_public.setText(ecdsa.getPublicKeyBase64());
        txt_private.setText(ecdsa.getPrivateKeyBase64());
        txt_public.setCaretPosition(0);
        txt_private.setCaretPosition(0);
    }

    private void initComponents() {
        setTitle("ECDSA Signature");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("CHỮ KÝ SỐ ECDSA (SHA256withECDSA)");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblTitle, gbc);

        // Row 1: Public key
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        panel.add(new JLabel("Public key:"), gbc);

        txt_public = new JTextArea(2, 45);
        txt_public.setLineWrap(true);
        txt_public.setWrapStyleWord(true);
        txt_public.setEditable(false);
        JScrollPane spPub = new JScrollPane(txt_public);
        spPub.setPreferredSize(new Dimension(600, 46));
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(spPub, gbc);

        // Row 2: Private key
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Private key:"), gbc);

        txt_private = new JTextArea(2, 45);
        txt_private.setLineWrap(true);
        txt_private.setWrapStyleWord(true);
        txt_private.setEditable(false);
        JScrollPane spPri = new JScrollPane(txt_private);
        spPri.setPreferredSize(new Dimension(600, 46));
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(spPri, gbc);

        // Row 3: Buttons Generate / Save / Load
        JPanel keyBtnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        btn_generate = new JButton("Generate Keys");
        btn_generate.setPreferredSize(new Dimension(140, 30));
        btn_savekeys = new JButton("Save Keys");
        btn_savekeys.setPreferredSize(new Dimension(120, 30));
        btn_loadkeys = new JButton("Load Keys");
        btn_loadkeys.setPreferredSize(new Dimension(120, 30));
        keyBtnPanel.add(btn_generate);
        keyBtnPanel.add(btn_savekeys);
        keyBtnPanel.add(btn_loadkeys);

        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(keyBtnPanel, gbc);

        // Row 4: Message
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Message:"), gbc);

        txt_message = new JTextArea(2, 45);
        txt_message.setLineWrap(true);
        txt_message.setWrapStyleWord(true);
        JScrollPane spMsg = new JScrollPane(txt_message);
        spMsg.setPreferredSize(new Dimension(600, 56));
        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(spMsg, gbc);

        // Row 5: Signature
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("Signature:"), gbc);

        txt_signature = new JTextArea(2, 45);
        txt_signature.setLineWrap(true);
        txt_signature.setWrapStyleWord(true);
        JScrollPane spSig = new JScrollPane(txt_signature);
        spSig.setPreferredSize(new Dimension(600, 56));
        gbc.gridx = 1;
        gbc.gridy = 5;
        panel.add(spSig, gbc);

        // Row 6: Buttons Sign / Verify / Result Label
        JPanel signBtnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        btn_sign = new JButton("Sign");
        btn_sign.setPreferredSize(new Dimension(110, 30));
        btn_verify = new JButton("Verify");
        btn_verify.setPreferredSize(new Dimension(110, 30));
        lbl_result = new JLabel("");
        lbl_result.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbl_result.setPreferredSize(new Dimension(300, 38));
        signBtnPanel.add(btn_sign);
        signBtnPanel.add(btn_verify);
        signBtnPanel.add(lbl_result);

        gbc.gridx = 1;
        gbc.gridy = 6;
        panel.add(signBtnPanel, gbc);

        // Row 7: Status
        lbl_status = new JLabel("Bấm Generate Keys hoặc Load Keys.");
        lbl_status.setPreferredSize(new Dimension(600, 36));
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        panel.add(lbl_status, gbc);

        setContentPane(panel);
        pack();

        // Event handling
        btn_generate.addActionListener(evt -> btn_generateActionPerformed(evt));
        btn_savekeys.addActionListener(evt -> btn_savekeysActionPerformed(evt));
        btn_loadkeys.addActionListener(evt -> btn_loadkeysActionPerformed(evt));
        btn_sign.addActionListener(evt -> btn_signActionPerformed(evt));
        btn_verify.addActionListener(evt -> btn_verifyActionPerformed(evt));
    }

    private void btn_generateActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            ecdsa.generateKeys();
            showKeys();
            lbl_status.setText("Đã tạo cặp khóa mới. Bản mã/chữ ký cũ sẽ không dùng được với khóa mới.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không tạo được khóa: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_savekeysActionPerformed(java.awt.event.ActionEvent evt) {
        if (txt_public.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chưa có khóa để lưu.");
            return;
        }
        String content = CryptoSupport.toKeyFile(txt_public.getText(), txt_private.getText());
        String path = FileTextIO.saveString(this, content, "ecdsa_keys.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu khóa vào: " + path + " (giữ bí mật dòng PRIVATE).");
        }
    }

    private void btn_loadkeysActionPerformed(java.awt.event.ActionEvent evt) {
        String content = FileTextIO.openString(this);
        if (content == null) {
            return;
        }
        try {
            String[] keys = CryptoSupport.fromKeyFile(content);
            ecdsa.loadKeys(keys[0], keys[1]);
            txt_public.setText(keys[0]);
            txt_private.setText(keys[1]);
            lbl_status.setText("Đã nạp khóa từ tệp.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Tệp khóa không hợp lệ: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_signActionPerformed(java.awt.event.ActionEvent evt) {
        String message = txt_message.getText();
        try {
            txt_signature.setText(ecdsa.sign(message));
            lbl_result.setText("");
            lbl_status.setText("Đã ký bằng KHÓA RIÊNG. " + HistoryDao.tryInsert("ECDSA", "SIGN", message.length(), true));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ký thất bại: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_verifyActionPerformed(java.awt.event.ActionEvent evt) {
        String message = txt_message.getText();
        try {
            boolean ok = ecdsa.verify(message, txt_signature.getText());
            lbl_result.setText(ok ? "VALID" : "INVALID");
            lbl_result.setForeground(ok ? new java.awt.Color(0, 128, 0) : java.awt.Color.RED);
            lbl_status.setText("Đã xác minh bằng KHÓA CÔNG KHAI. " + HistoryDao.tryInsert("ECDSA", "VERIFY", message.length(), ok));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Xác minh thất bại: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_ECC_Signature().setVisible(true));
    }
}
