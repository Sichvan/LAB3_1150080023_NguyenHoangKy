package week_03;

import java.awt.*;
import javax.swing.*;

public class frm_KetNoiSQL extends JFrame {
    private JTextField txt_server, txt_port, txt_database, txt_user;
    private JPasswordField txt_password;
    private JButton btn_test, btn_history;
    private JLabel lbl_status;

    public frm_KetNoiSQL() {
        setTitle("Kết nối Microsoft SQL Server");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(520, 380);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new GridBagLayout());
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);
        g.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("KẾT NỐI MICROSOFT SQL SERVER");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2;
        root.add(lblTitle, g);

        g.gridwidth = 1;
        txt_server = new JTextField("127.0.0.1", 25);
        txt_port = new JTextField("14333", 10);
        txt_database = new JTextField("LAB3_MaHoaKhoaCongKhai", 25);
        txt_user = new JTextField("lab3_user", 25);
        txt_password = new JPasswordField(25);

        addRow(root, g, 1, "Server:", txt_server);
        addRow(root, g, 2, "Port:", txt_port);
        addRow(root, g, 3, "Database:", txt_database);
        addRow(root, g, 4, "User:", txt_user);
        addRow(root, g, 5, "Password:", txt_password);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btn_test = new JButton("Test Connection");
        btn_history = new JButton("Xem lịch sử");
        btnPanel.add(btn_test);
        btnPanel.add(btn_history);
        g.gridx = 1; g.gridy = 6;
        root.add(btnPanel, g);

        lbl_status = new JLabel("Chưa kết nối.");
        g.gridx = 0; g.gridy = 7; g.gridwidth = 2;
        root.add(lbl_status, g);

        setContentPane(root);

        btn_test.addActionListener(e -> {
            try {
                int port = Integer.parseInt(txt_port.getText().trim());
                DbConfig.set(txt_server.getText().trim(), port, txt_database.getText().trim(),
                        txt_user.getText().trim(), txt_password.getPassword());
                lbl_status.setText("<html>" + DbConfig.test() + "</html>");
            } catch (Exception ex) {
                DbConfig.clear();
                lbl_status.setText("<html>Kết nối thất bại: " + ex.getMessage() + "</html>");
                JOptionPane.showMessageDialog(this, ex.getMessage(),
                        "Không kết nối được SQL Server", JOptionPane.ERROR_MESSAGE);
            }
        });

        btn_history.addActionListener(e -> new frm_LichSu().setVisible(true));
    }

    private void addRow(JPanel panel, GridBagConstraints g, int row, String label, JComponent comp) {
        g.gridx = 0; g.gridy = row; g.weightx = 0;
        panel.add(new JLabel(label), g);
        g.gridx = 1; g.weightx = 1;
        panel.add(comp, g);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_KetNoiSQL().setVisible(true));
    }
}