package week_03;

import java.awt.*;
import javax.swing.*;

public class frm_LichSu extends JFrame {
    private JTable tbl_history;
    private JButton btn_refresh;
    private JLabel lbl_status;

    public frm_LichSu() {
        setTitle("Lịch sử thao tác (SQL Server)");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(800, 420);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lblTitle = new JLabel("LỊCH SỬ THAO TÁC - BẢNG DBO.HISTORY");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        root.add(lblTitle, BorderLayout.NORTH);

        tbl_history = new JTable(HistoryDao.emptyModel());
        root.add(new JScrollPane(tbl_history), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btn_refresh = new JButton("Tải lại");
        btn_refresh.setPreferredSize(new Dimension(110, 30));
        lbl_status = new JLabel("Đang tải...");
        bottom.add(btn_refresh);
        bottom.add(lbl_status);
        root.add(bottom, BorderLayout.SOUTH);

        setContentPane(root);

        btn_refresh.addActionListener(e -> loadData());
        loadData();
    }

    private void loadData() {
        try {
            tbl_history.setModel(HistoryDao.loadLatest(50));
            lbl_status.setText("Đã tải " + tbl_history.getRowCount() + " dòng mới nhất từ dbo.History.");
        } catch (java.sql.SQLException ex) {
            lbl_status.setText("Không đọc được lịch sử: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_LichSu().setVisible(true));
    }
}