package week_03;

import java.awt.*;
import javax.swing.*;

public class frm_Menu extends javax.swing.JFrame {

    private JButton btn_rsa;
    private JButton btn_ecc;
    private JButton btn_rsaaes;
    private JButton btn_signature;
    private JButton btn_sql;
    private JButton btn_history;

    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("LAB 3 - Mã hóa khóa công khai");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("LAB 3 - MÃ HÓA KHÓA CÔNG KHAI");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        panel.add(lblTitle, gbc);

        JLabel lblSubtitle = new JLabel("Chọn một bài để mở form tương ứng (bài 3.1 chạy RSADemo.java bằng Run File):");
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        panel.add(lblSubtitle, gbc);

        gbc.gridwidth = 1;
        btn_rsa = new JButton("3.2 RSA (Swing)");
        btn_rsa.setPreferredSize(new Dimension(200, 30));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(btn_rsa, gbc);

        btn_ecc = new JButton("3.3 ECC");
        btn_ecc.setPreferredSize(new Dimension(200, 30));
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(btn_ecc, gbc);

        btn_rsaaes = new JButton("3.4 RSA + AES");
        btn_rsaaes.setPreferredSize(new Dimension(200, 30));
        gbc.gridx = 2;
        gbc.gridy = 2;
        panel.add(btn_rsaaes, gbc);

        btn_signature = new JButton("3.5 Chữ ký ECDSA");
        btn_signature.setPreferredSize(new Dimension(200, 30));
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(btn_signature, gbc);

        btn_sql = new JButton("Kết nối SQL Server");
        btn_sql.setPreferredSize(new Dimension(200, 30));
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(btn_sql, gbc);

        btn_history = new JButton("Xem lịch sử");
        btn_history.setPreferredSize(new Dimension(200, 30));
        gbc.gridx = 2;
        gbc.gridy = 3;
        panel.add(btn_history, gbc);

        setContentPane(panel);
        pack();

        btn_rsa.addActionListener(evt -> btn_rsaActionPerformed(evt));
        btn_ecc.addActionListener(evt -> btn_eccActionPerformed(evt));
        btn_rsaaes.addActionListener(evt -> btn_rsaaesActionPerformed(evt));
        btn_signature.addActionListener(evt -> btn_signatureActionPerformed(evt));
        btn_sql.addActionListener(evt -> btn_sqlActionPerformed(evt));
        btn_history.addActionListener(evt -> btn_historyActionPerformed(evt));
    }

    private void btn_rsaActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_RSA().setVisible(true);
    }

    private void btn_eccActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_ECC().setVisible(true);
    }

    private void btn_rsaaesActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_RSA_AES().setVisible(true);
    }

    private void btn_signatureActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_ECC_Signature().setVisible(true);
    }

    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }

    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}
